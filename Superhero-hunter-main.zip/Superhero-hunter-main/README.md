# Superhero-hunter

## Home Page (Light Theme)
![home-page-light](https://user-images.githubusercontent.com/66960784/203381630-31bc1e97-e992-4b83-b2c7-a1db7d29ec04.png)

## Home Page (Dark Theme)
![home-page-dark](https://user-images.githubusercontent.com/66960784/203381701-ba5cc4ff-cb3e-4f26-a627-fdf9d5d72d4f.png)


## Empty favourites page (Light Theme)
![Empty-favourites-page-light](https://user-images.githubusercontent.com/66960784/203382730-c6c4e5f6-33cf-4013-b52b-e8c3d8c1ae43.png)

## Empty favourites page (Light Theme)
![Empty-favourites-page-dark](https://user-images.githubusercontent.com/66960784/203382741-ca8d8c49-d32b-4c0e-8d79-308ee15d5b97.png)

## Home Page with searched items (Light Theme)
![Home-page-with-searched-items-light](https://user-images.githubusercontent.com/66960784/203382400-493f96f8-00af-4588-a7fa-a6759bdfb5d3.png)

## Home Page with searched items (Dark Theme)
![Home-page-with-searched-items-dark](https://user-images.githubusercontent.com/66960784/203382426-1e51fbb6-9787-4732-b208-049006312fb9.png)

## Favourites page with favourites characters (Light Theme)
![Favourites-page-with-favourites-characters-llight](https://user-images.githubusercontent.com/66960784/203382952-e51bd5ae-6042-4f3a-8065-c806dd3d3443.png)

## Favourites page with favourites characters (Dark Theme)
![Favourites-page-with-favourites-characters-dark](https://user-images.githubusercontent.com/66960784/203382969-a8868cec-7e3f-4f65-ac42-e8bf774bb61c.png)

## More Info (Light Theme)
![more-info-page-light](https://user-images.githubusercontent.com/66960784/203383576-93d26828-ec05-46c1-b6e7-1032a2c32b28.png)

## More Info (Dark Theme)
![more-info-page-dark](https://user-images.githubusercontent.com/66960784/203383629-fff285f9-9aa4-4e70-840c-da961e0b59e2.png)
